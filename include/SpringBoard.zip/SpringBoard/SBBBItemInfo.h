@interface SBBBItemInfo : NSObject

@end
