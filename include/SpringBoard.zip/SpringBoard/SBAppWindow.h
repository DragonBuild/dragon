@interface SBAppWindow : NSObject

@end
