@interface SBStatusBarOperatorNameView : NSObject

@end
