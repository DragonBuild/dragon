@class SBIconView, SBFolder;

@interface SBFolderIconView : SBIconView

@property (nonatomic, retain, readonly) SBFolder *folder;

@end
