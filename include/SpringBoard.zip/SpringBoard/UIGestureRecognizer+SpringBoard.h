#import <UIKit/UIGestureRecognizer.h>

@interface UIGestureRecognizer (SpringBoard)

- (void)sb_setStylusTouchesAllowed:(BOOL)touchesAllowed;

@end