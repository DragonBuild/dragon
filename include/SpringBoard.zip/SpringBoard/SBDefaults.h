@class SBExternalDefaults;

@interface SBDefaults : NSObject

+ (SBExternalDefaults *)externalDefaults;

@end