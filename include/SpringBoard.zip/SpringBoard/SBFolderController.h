@class SBFolderView;

@interface SBFolderController : NSObject

@property (nonatomic, retain, readonly) SBFolderView *contentView;

@end
