#import "SBWorkspaceEntity.h"

@interface SBWorkspaceHomeScreenEntity : SBWorkspaceEntity

- (BOOL)isHomeScreenEntity;

@end
