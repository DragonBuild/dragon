@class SBIcon;

@interface SBIconView : UIView

+ (CGSize)defaultIconSize;

@property (nonatomic, retain) SBIcon *icon;

@end
