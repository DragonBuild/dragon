@interface SBHomeGrabberView : UIView

- (CGRect)_calculatePillFrame;

@end
