@interface SBNotificationCell : UITableViewCell

@property (nonatomic, retain) UIView *realContentView;

@end
