@interface SBWallpaperView : UIImageView

@end
