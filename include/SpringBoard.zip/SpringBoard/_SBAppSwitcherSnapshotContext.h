@class XBApplicationSnapshot;

@interface _SBAppSwitcherSnapshotContext : NSObject

@property (nonatomic, retain) XBApplicationSnapshot *snapshot;

@end
