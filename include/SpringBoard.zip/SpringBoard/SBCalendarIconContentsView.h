@interface SBCalendarIconContentsView : NSObject

@end
