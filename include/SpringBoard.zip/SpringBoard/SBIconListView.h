@interface SBIconListView : UIView

- (void)setAlphaForAllIcons:(CGFloat)alpha;

@end
