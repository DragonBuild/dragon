@interface SBDisplayLayout : NSObject

@property (nonatomic, retain, readonly) NSArray *displayItems;

@end
