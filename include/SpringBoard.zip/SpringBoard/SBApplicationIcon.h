#import "SBLeafIcon.h"

@class SBApplication;

@interface SBApplicationIcon : SBLeafIcon

- (instancetype)initWithApplication:(SBApplication *)application;

@end
