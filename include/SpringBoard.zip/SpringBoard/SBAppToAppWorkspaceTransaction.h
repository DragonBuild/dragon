#import "SBToAppsWorkspaceTransaction.h"

@interface SBAppToAppWorkspaceTransaction : SBToAppsWorkspaceTransaction

- (void)_begin;

@end
