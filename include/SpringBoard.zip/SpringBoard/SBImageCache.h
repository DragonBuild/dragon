@interface SBImageCache : NSObject

@end
