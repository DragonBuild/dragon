@interface SBIconContentView : UIView

@end
