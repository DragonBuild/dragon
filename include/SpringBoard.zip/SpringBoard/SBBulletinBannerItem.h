@interface SBBulletinBannerItem : NSObject

- (BBBulletin *)seedBulletin;

@end
