@interface SBStatusBarController : NSObject

@end
