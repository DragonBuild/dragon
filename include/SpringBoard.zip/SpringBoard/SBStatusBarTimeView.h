@interface SBStatusBarTimeView : NSObject

@end
