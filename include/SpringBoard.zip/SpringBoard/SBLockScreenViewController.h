@interface SBLockScreenViewController : UIViewController

@end
