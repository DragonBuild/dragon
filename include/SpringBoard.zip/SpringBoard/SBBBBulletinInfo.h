#import "SBBBItemInfo.h"

@interface SBBBBulletinInfo : SBBBItemInfo

@property (nonatomic, retain, readonly) BBBulletin *representedBulletin;

@end
