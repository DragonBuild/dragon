@class SBFolder, SBIcon;

@interface SBRootFolder : SBFolder

- (NSIndexPath *)indexPathForIcon:(SBIcon *)icon;

@end
