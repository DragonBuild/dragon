#import "SBBBItemInfo.h"

@interface SBBBSectionInfo : SBBBItemInfo

@property (nonatomic, retain) NSString *identifier;

@end
