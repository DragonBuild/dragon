@interface SBExternalCarrierDefaults : NSObject

@property (readonly, nonatomic) NSString *carrierName;

@end