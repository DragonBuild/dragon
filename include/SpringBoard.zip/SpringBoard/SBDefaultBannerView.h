@interface SBDefaultBannerView : UIView

@end
