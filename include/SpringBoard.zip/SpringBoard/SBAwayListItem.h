@interface SBAwayListItem : NSObject

@end
