@interface SBWallpaperPreviewSnapshotCache : NSObject

- (UIImage *)homeScreenSnapshot;
- (UIImage *)lockScreenSnapshot;

@end
