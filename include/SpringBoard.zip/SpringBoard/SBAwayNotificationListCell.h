@class BBBulletin;

@interface SBAwayNotificationListCell : UITableViewCell

@property (nonatomic, retain) BBBulletin *bulletin;

@end
